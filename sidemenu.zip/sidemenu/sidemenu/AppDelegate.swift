//
//  AppDelegate.swift
//  sidemenu
//
//  Created by Drashti on 11/12/23.
//

import UIKit
import SideMenu

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

   


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
//        let menuLeftNavigationController = SideMenuNavigationController(rootViewController: UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Menu"))
//                //    SideMenuManager.default.menuLeftNavigationController = menuLeftNavigationController
//                //    SideMenuManager.default.menuLeftNavigationController?.navigationBar.isHidden = true
//                
//        SideMenuManager.default.rightMenuNavigationController = menuLeftNavigationController
//        SideMenuManager.default.rightMenuNavigationController?.navigationBar.isHidden = true
//                
//        //        SideMenuManager.default.menuAddPanGestureToPresent(toView: (self.window?.rootViewController?.navigationController?.navigationBar)!)
//        //        SideMenuManager.default.menuAddScreenEdgePanGesturesToPresent(toView: (self.window?.rootViewController?.navigationController?.navigationBar)!)
//                
//                //SideMenuManager.default.menuFadeStatusBar = false
//                
//                SideMenuManager.defaultManager.menuWidth = (appDelegate.window?.frame.size.width)! - ((appDelegate.window?.frame.size.width)! / 4)
                
                
                return true
        
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

