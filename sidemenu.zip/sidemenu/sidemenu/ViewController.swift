//
//  ViewController.swift
//  sidemenu
//
//  Created by Drashti on 11/12/23.
//

import UIKit
import SideMenu

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    @IBAction func btmMenu(_ sender: UIButton) {
        //present(SideMenuManager.default.rightMenuNavigationController!, animated: true, completion: nil)
        
        let menu = SideMenuNavigationController(rootViewController: UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Menu"))
        menu.menuWidth = UIScreen.main.bounds.width - (UIScreen.main.bounds.width / 4)
        //view.frame.size.width - (view.frame.size.width/4)
        present(menu, animated: true, completion: nil)
    }
    
}

